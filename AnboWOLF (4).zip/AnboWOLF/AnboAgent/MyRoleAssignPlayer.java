package org.aiwolf.AnboAgent;

import org.aiwolf.client.base.player.AbstractRoleAssignPlayer;

public class MyRoleAssignPlayer extends AbstractRoleAssignPlayer {

	public MyRoleAssignPlayer(){
	setSeerPlayer(new MySeer());
	setVillagerPlayer(new MyVillager());
	setBodyguardPlayer(new MyBodyguard());
	setMediumPlayer(new MyMedium());
	setWerewolfPlayer(new MyWerewolf());
	setPossessedPlayer(new MyPossessed());
	}

	@Override
	public String getName() {
		// TODO 自動生成されたメソッド・スタブ
		return "Anbonanza";
	}

}
