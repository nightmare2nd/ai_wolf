package org.aiwolf.AnboAgent;

import java.util.ArrayList;
import java.util.List;

import org.aiwolf.client.base.player.AbstractSeer;
import org.aiwolf.client.lib.TemplateTalkFactory;
import org.aiwolf.client.lib.Utterance;
import org.aiwolf.common.data.Agent;
import org.aiwolf.common.data.Judge;
import org.aiwolf.common.data.Role;
import org.aiwolf.common.data.Species;
import org.aiwolf.common.data.Talk;
import org.aiwolf.common.data.Vote;
import org.aiwolf.common.net.GameInfo;

public class MySeer extends AbstractSeer {

	//その日のログの何番目まで読み込んだか
	int readTalkNum = 0;
	@Override
	public void dayStart() {
		// TODO 自動生成されたメソッド・スタブ
	}

	//占い師、霊媒師、狩人の人数
	int COUNT_SEER = 0;
	int COUNT_MEDIUM = 0;
	int COUNT_BODYGUARD = 0;
	//占い、霊媒を行った数
	int COUNT_DIVINED = 0;
	int COUNT_INQUESTED = 0;
	int COUNT_GUARDED = 0;
	//生きている人狼数
	int Alive_WOLF = 3;
	//生きている占い師、霊媒師、狩人数
	int Alive_SEER = 0;
	int Alive_MEDIUM = 0;
	int Alive_BODYGUARD =0;
	//人狼度
	int WOLF[];
	//発言者、対象者、役職のカミングアウト、投票による信用度
	List<Agent> List_Agent = new ArrayList<Agent>();
	List<Agent> List_Target = new ArrayList<Agent>();
	List<Role> List_Role = new ArrayList<Role>();
	//生死状況
	int Alive[];
	int BELL[][];
	//占った人、占われた人、占い結果
	List<Agent> List_DIVINED_Agent = new ArrayList<Agent>();
	List<Agent> List_DIVINED_Target = new ArrayList<Agent>();
	List<Species> List_DIVINED_Result = new ArrayList<Species>();
	//霊媒した人、霊媒された人、霊媒結果
	List<Agent> List_INQUESTED_Agent = new ArrayList<Agent>();
	List<Agent> List_INQUESTED_Target = new ArrayList<Agent>();
	List<Species> List_INQUESTED_Result = new ArrayList<Species>();
	//護衛した人、された人
	List<Agent> List_GUARDED_Agent = new ArrayList<Agent>();
	List<Agent> List_GUARDED_Target = new ArrayList<Agent>();
	//吊るされたリスト
	List<Agent> List_EXECUTED = new ArrayList<Agent>();


	//白黒の確定リスト
	List<Agent> whiteAgent = new ArrayList<Agent>(),//白判定だったプレイヤー
				blackAgent = new ArrayList<Agent>();//黒判定だったプレイヤー

	@Override
	public void update(GameInfo gameInfo){
		//今日のログを取得
		super.update(gameInfo);
		List_Agent.addAll(gameInfo.getAgentList());//発話者を格納
		List_Target.addAll(gameInfo.getAgentList());//対象者を格納
		for (int a = 0; a < 15; a++){
			List_Role.add(Role.VILLAGER);
		}
		BELL = new int[15][15];//信用度の作成
		//生死状態の初期設定、始めはみんな生きている
		Alive =new int[15];
		for (int a = 0; a < 15; a++){
			Alive[a] = 1;
		}
		//人狼度の初期設定
		WOLF =new int[15];
		for (int a = 0; a < 15; a++){
			WOLF[a] = 0;
		}
		
		
		//投票ログ
		List<Vote> voteList = gameInfo.getVoteList();
		for(int a = 0; a < voteList.size(); a++){
			Vote vote = voteList.get(a);
			//投票先の信用度を-1
			for(int b = 0; b < 15; b++){
				if (List_Agent.get(b) == vote.getAgent()){
					for(int c =0; c < 15; c++){
						if (List_Target.get(c) == vote.getTarget()){
							BELL[b][c] = BELL[b][c]-1;
						}
					}
				}
			}//
			//投票先が占い師と同じ場合その占い師の信用度を+1
			for(int b = 0; b < 15; b++){
				if (List_Role.get(b) == Role.SEER){
					for(int c =0; c < 15; c++){
						if (List_Target.get(c) == List_Target.get(b) & c!=b){
							BELL[c][b] = BELL[c][b]+1;
						}
					}
				}
			}//
			//お互いに投票していない場合、それぞれの人狼度を+20する、信用度を+1
			for(int b = 0; b < 15; b++){
				for(int c = 0; c < 15; c++){
					if(BELL[b][c] == 0 & BELL[c][b] ==0 & b!=c){
						WOLF[b] =WOLF[b]+20;
						WOLF[c] =WOLF[c]+20;
						BELL[b][c] = BELL[b][c]+1;
						BELL[c][b] = BELL[c][b]+1;
					}
				}
			}//
		}//

		//投票結果ログ
		//生死状態を更新
		for(int i = 0; i < 15; i++){
			if(List_Target.get(i) == getLatestDayGameInfo().getExecutedAgent()){
				Alive[i] = 0;
				//さらに偽占い師の場合は生存占い師数を-1する
				if(List_Role.get(i) == Role.SEER){
					//Alive_SEER = Alive_SEER - 1;
					Alive_WOLF = Alive_WOLF -1;
				}//
				//さらに霊媒師の場合は生存霊媒師数を-1する
				if(List_Role.get(i) == Role.MEDIUM){
					Alive_MEDIUM = Alive_MEDIUM - 1;
				}//
				//さらに狩人の場合は生存狩人数を-1する
				if(List_Role.get(i) == Role.BODYGUARD){
					Alive_BODYGUARD = Alive_BODYGUARD - 1;
				}//
			}
		}//



		//襲撃ログ
		//生死状態の更新、襲撃された人の人狼度を0にする
		for(int i = 0; i < 15; i++){
			if(List_Target.get(i) == getLatestDayGameInfo().getAttackedAgent()){
				Alive[i] = 0;
				WOLF[i] = 0;
				//さらに占い師の場合は生存占い師数を-1し、生きている占い師の人狼度を+100する
				if(List_Role.get(i) == Role.SEER){
					//Alive_SEER = Alive_SEER - 1;
					Alive_WOLF = Alive_WOLF - 1;
					//for(int j =0; j < 15; j++){
						//if(List_Role.get(j) == Role.SEER & i != j){
							//WOLF[j] = WOLF[j] + 50;
						//}
					}
				}//
				//さらに霊媒師の場合は生存霊媒師数を-1し、生きている占い師の人狼度を+100する
				if(List_Role.get(i) == Role.MEDIUM){
					Alive_MEDIUM = Alive_MEDIUM - 1;
					for(int j =0; j < 15; j++){
						if(List_Role.get(j) == Role.MEDIUM & i != j){
							WOLF[j] = WOLF[j] + 50;
						}
					}
				}//
				//さらに狩人の場合は生存狩人数を-1し、生きている狩人の人狼度を+100する
				if(List_Role.get(i) == Role.BODYGUARD){
					Alive_BODYGUARD = Alive_BODYGUARD - 1;
					for(int j =0; j < 15; j++){
						if(List_Role.get(j) == Role.BODYGUARD & i != j){
							WOLF[j] = WOLF[j] + 50;
						}
					}
				}//
				//襲撃された人を黒判定した占い師をブラックリストに追加
				//for(int j = 0; j < COUNT_DIVINED; j++){
					//if(List_DIVINED_Target.get(j) == List_Target.get(i) & List_DIVINED_Result.get(j) == Species.WEREWOLF){
						//blackAgent.add(List_DIVINED_Agent.get(j));
						//人狼度+100
						//for(int k=0; k<15; k++){
							//if(List_Agent.get(k)==List_DIVINED_Agent.get(j)){
								//WOLF[k] = WOLF[k]+100;
							//}
						//}
					//}
				//}
				//襲撃された人を黒判定した霊媒師をブラックリストに追加
				for(int j = 0; j < COUNT_INQUESTED; j++){
					if(List_INQUESTED_Target.get(j) == List_Target.get(i) & List_INQUESTED_Result.get(j) == Species.WEREWOLF){
						blackAgent.add(List_INQUESTED_Agent.get(j));
						//人狼度+100
						for(int k=0; k<15; k++){
							if(List_Agent.get(k)==List_INQUESTED_Agent.get(j)){
								WOLF[k] = WOLF[k]+100;
							}
						}
					}
				}
			}
		//}//

		//talkログ
		List<Talk> talkList = gameInfo.getTalkList();
		for(int i = 0; i < talkList.size(); i++){
			Talk talk = talkList.get(i);
			//発話をパース
			Utterance utterance = new Utterance(talk.getContent());
			//発話のトピックごとに処理
			switch (utterance.getTopic()){
			case COMINGOUT:
				if(utterance.getRole() == Role.SEER){
					//占い師数
					COUNT_SEER = +1;
					//エージェントの役職を占い師にする
					for(int b = 0; b < 15; b++){
						if (List_Agent.get(b) == talk.getAgent()){
							List_Role.set(b, Role.SEER);
						}
					}//
				}
				if(utterance.getRole() == Role.MEDIUM){
					//霊媒師数
					COUNT_MEDIUM = +1;
					//エージェントの役職を霊媒師にする
					for(int b = 0; b < 15; b++){
						if (List_Agent.get(b) == talk.getAgent()){
							List_Role.set(b, Role.MEDIUM);
						}
					}//
				}
				if(utterance.getRole() == Role.BODYGUARD){
					//占い師数
					COUNT_BODYGUARD = +1;
					//エージェントの役職を狩人にする
					for(int b = 0; b < 15; b++){
						if (List_Agent.get(b) == talk.getAgent()){
							List_Role.set(b, Role.BODYGUARD);
						}
					}//
				}
				break;
			case DIVINED:
				//占いが行われた数
				//COUNT_DIVINED = +1;
				//占った人、占われた人、占い結果を格納
				//List_DIVINED_Agent.add(talk.getAgent());
				//List_DIVINED_Target.add(utterance.getTarget());
				//List_DIVINED_Result.add(utterance.getResult());
				//占い結果が白の場合、占い師と占われた人の人狼度を-50する
				//if(utterance.getResult() == Species.HUMAN){
					//for(int j = 0; j < 15; j++){
						//if(List_Agent.get(j) == talk.getAgent()){
							//WOLF[j] = WOLF[j] - 50;
						//}
						//if(List_Agent.get(j) == utterance.getTarget()){
							//WOLF[j] = WOLF[j] - 50;
						//}
					//}
				//}
				//自分を黒と占った占い師をブラックリストに追加
				//if(utterance.getTarget() == getMe() & utterance.getResult() == Species.WEREWOLF){
					//blackAgent.add(talk.getAgent());
					//人狼度+100
					//for(int k=0; k<15; k++){
						//if(List_Agent.get(k)==talk.getAgent()){
							//WOLF[k] = WOLF[k]+100;
						//}
					//}
				//}
				break;
			case INQUESTED:
				//霊媒が行われた数
				COUNT_INQUESTED = +1;
				//霊媒した人、霊媒された人、霊媒結果を格納
				List_INQUESTED_Agent.add(talk.getAgent());
				List_INQUESTED_Target.add(utterance.getTarget());
				List_INQUESTED_Result.add(utterance.getResult());
				break;
			case VOTE:
				break;
			case ESTIMATE:
				break;
			case GUARDED:
				//防衛が行われた数
				COUNT_GUARDED = +1;
				//護衛した人、護衛された人、護衛結果を格納
				List_GUARDED_Agent.add(talk.getAgent());
				List_GUARDED_Target.add(utterance.getTarget());
				break;
			case AGREE:
				break;
			case DISAGREE:
				break;
			case ATTACK:
				break;
			case OVER:
				break;
			case SKIP:
				break;
		}
		}
	}


	@Override
	public void finish() {
		// TODO 自動生成されたメソッド・スタブ


	}

	//既に役職のカミングアウトしているか
		boolean isComingOut = false;
		List<Agent> myToldJudgeList = new ArrayList<Agent>();

		@Override
		public String talk() {
			// TODO 自動生成されたメソッド・スタブ
			if(!isComingOut){
				for(Judge judge: getMyJudgeList()){
					if(judge.getResult() == Species.WEREWOLF){//霊能結果が人狼の場合
						String comingoutTalk = TemplateTalkFactory.comingout(getMe(),getMyRole());
						isComingOut = true;
						return comingoutTalk;
					}
				}
			}
			else{//カミングアウトした後は、まだ言っていない霊能結果を順次報告
				for(Judge judge: getMyJudgeList()){
					if(!myToldJudgeList.contains(judge.getTarget())){//まだ報告していないJudgeの場合
						String resultTalk = TemplateTalkFactory.divined(judge.getTarget(),judge.getResult());
						myToldJudgeList.add(judge.getTarget());
						return resultTalk;
					}
				}
			}
			//話すことが無ければ会話終了
			return Talk.OVER;
		}

		@Override
		public Agent divine() {
			// TODO 自動生成されたメソッド・スタブ
			//占い対象の候補者リスト
			List<Agent> divineCandidates = new ArrayList<Agent>();
			//生きているプレイヤーを候補者リストに加える
			divineCandidates.addAll(getLatestDayGameInfo().getAliveAgentList());
			//自分自身と既に占ったことのあるプレイヤーは候補から外す
			divineCandidates.remove(getMe());
			for(Judge judge:getMyJudgeList()){
				if(divineCandidates.contains(judge.getTarget())){
					divineCandidates.remove(judge.getTarget());
				}
		        if(divineCandidates.size() > 0){
		        	//候補者リストからランダムに選択
		        	return divineCandidates.get(0);
		        }else{
		        	//候補者がいない場合は自分を占う
		        	return getMe();
		        }
			}
			return null;
		}

	@Override
	public Agent vote() {
		//今まで霊媒したプレイヤーをwhiteAgentとblackAgentに分ける
		for(Judge judge: getMyJudgeList()){
			if (getLatestDayGameInfo().getAliveAgentList().contains(judge.getTarget())){
				switch (judge.getResult()){
				case HUMAN:
					whiteAgent.add(judge.getTarget());
					for(int j=0; j<15; j++){
						if(List_Agent.get(j)==judge.getTarget()&List_Role.get(j)!=Role.SEER){
							WOLF[j] = 0;
						}
					}
							break;
							case WEREWOLF:
								blackAgent.add(judge.getTarget());
								for(int j=0; j<15; j++){
									if(List_Agent.get(j)==judge.getTarget()){
										WOLF[j] = WOLF[j]+100;
									}
								}
				}
			}
		}
		
		//占い、霊能結果の格納
		int DIVINED[];
		int INQUESTED[];
		DIVINED = new int[15];
		INQUESTED = new int[15];
		//占い確定黒、白の格納
		//for(int b = 0; b < COUNT_DIVINED; b++){
			//if (List_DIVINED_Result.get(b) == Species.WEREWOLF){
				//for(int c =0; c < 15; c++){
					//if (List_Target.get(c) == List_DIVINED_Target.get(b)){
						//DIVINED[c] = DIVINED[c]+1;
					//}
				//}//
			//}
			//if (List_DIVINED_Result.get(b) == Species.HUMAN){
				//for(int c =0; c < 15; c++){
					//if (List_Target.get(c) == List_DIVINED_Target.get(b)){
						//DIVINED[c] = DIVINED[c]-1;
					//}
				//}
			//}
		//}
		//for(int b = 0; b < 15; b++){
			//if(DIVINED[b] == COUNT_SEER){
				//blackAgent.add( List_Target.get(b));
				//人狼度+100
				//for(int k=0; k<15; k++){
					//if(List_Agent.get(k)== List_Target.get(b)){
						//WOLF[k] = WOLF[k]+100;
					//}
				//}
				//Alive_WOLF = Alive_WOLF-1;//生きている人狼数を1減らす
			//}
			//if(DIVINED[b] == -COUNT_SEER){
				//whiteAgent.add( List_Target.get(b));
				//人狼度0
				//for(int k=0; k<15; k++){
					//if(List_Agent.get(k)== List_Target.get(b)){
						//WOLF[k] = 0;
					//}
				//}
			//}
		//}//
		//霊能確定黒、白の格納
		for(int b = 0; b < COUNT_INQUESTED; b++){
			if (List_INQUESTED_Result.get(b) == Species.WEREWOLF){
				for(int c =0; c < 15; c++){
					if (List_Target.get(c) == List_INQUESTED_Target.get(b)){
						INQUESTED[c] = INQUESTED[c]+1;
					}
				}
			}
			if (List_INQUESTED_Result.get(b) == Species.HUMAN){
				for(int c =0; c < 15; c++){
					if (List_Target.get(c) == List_INQUESTED_Target.get(b)){
						INQUESTED[c] = INQUESTED[c]-1;
					}
				}
			}
		}
		for(int b = 0; b < 15; b++){
			if(INQUESTED[b] == COUNT_MEDIUM){
				blackAgent.add( List_Target.get(b));
				Alive_WOLF = Alive_WOLF-1;//生きている人狼数を1減らす
				//人狼度+100
				for(int k=0; k<15; k++){
					if(List_Agent.get(k)== List_Target.get(b)){
						WOLF[k] = WOLF[k]+100;
					}
				}
			}
			if(INQUESTED[b] == -COUNT_MEDIUM){
				whiteAgent.add( List_Target.get(b));
				//人狼度0
				for(int k=0; k<15; k++){
					if(List_Agent.get(k)== List_Target.get(b)){
						WOLF[k] = 0;
					}
				}
			}
		}//
		//ブラックリスト、ホワイトリストと矛盾する占い、霊能、護衛をした占い師、霊媒師をブラックリストに追加、生存人狼数を-1
		//for(int i = 0; i < COUNT_DIVINED; i++){
			//if(List_DIVINED_Result.get(i) == Species.HUMAN & blackAgent.contains(List_DIVINED_Target.get(i))){
				//blackAgent.add(List_DIVINED_Agent.get(i));
				//Alive_WOLF = Alive_WOLF - 1;
				//人狼度+100
				//for(int k=0; k<15; k++){
					//if(List_Agent.get(k)==List_DIVINED_Agent.get(i)){
						//WOLF[k] = WOLF[k]+100;
					//}
				//}
			//}
			//if(List_DIVINED_Result.get(i) == Species.WEREWOLF & whiteAgent.contains(List_DIVINED_Target.get(i))){
				//blackAgent.add(List_DIVINED_Agent.get(i));
				//人狼度+100
				//for(int k=0; k<15; k++){
					//if(List_Agent.get(k)==List_DIVINED_Agent.get(i)){
						//WOLF[k] = WOLF[k]+100;
					//}
				//}
				//Alive_WOLF = Alive_WOLF - 1;
			//}
		//}
		for(int i = 0; i < COUNT_INQUESTED; i++){
			if(List_INQUESTED_Result.get(i) == Species.HUMAN & blackAgent.contains(List_INQUESTED_Target.get(i))){
				blackAgent.add(List_INQUESTED_Agent.get(i));
				//人狼度+100
				for(int k=0; k<15; k++){
					if(List_Agent.get(k)==List_INQUESTED_Agent.get(i)){
						WOLF[k] = 0;
					}
				}
				Alive_WOLF = Alive_WOLF - 1;
			}
			if(List_INQUESTED_Result.get(i) == Species.WEREWOLF & whiteAgent.contains(List_INQUESTED_Target.get(i))){
				blackAgent.add(List_INQUESTED_Agent.get(i));
				//人狼度+100
				for(int k=0; k<15; k++){
					if(List_Agent.get(k)==List_INQUESTED_Agent.get(i)){
						WOLF[k] = WOLF[k]+100;
					}
				}
				Alive_WOLF = Alive_WOLF - 1;
			}
		}
		for(int i = 0; i < COUNT_GUARDED; i++){
			if(blackAgent.contains(List_GUARDED_Target.get(i))){
				blackAgent.add(List_GUARDED_Agent.get(i));
				//人狼度+100
				for(int k=0; k<15; k++){
					if(List_Agent.get(k)==List_GUARDED_Agent.get(i)){
						WOLF[k] = WOLF[k]+100;
					}
				}
				Alive_WOLF = Alive_WOLF - 1;
			}
		}

		//白判定された人が生きていた場合、その人とその占いをした占い師の人狼度を50上げる
		for(int i = 0; i < COUNT_DIVINED; i++){
			if(List_DIVINED_Result.get(i) == Species.HUMAN){
				for(int j = 0; j < 15; j++){
					if(List_Agent.get(j) == List_DIVINED_Target.get(i) & Alive[j] ==1){
						WOLF[j] = WOLF[j] + 50;
						//for(int k = 0; k < 15; k++){
							//if(List_Agent.get(k) == List_DIVINED_Agent.get(i)){
								//WOLF[k] = WOLF[k] + 50;
							//}
						//}
					}
				}
			}
		}

		//狩人が襲撃されていない場合狩人の人狼度を+50する
		for(int i =0; i < 15; i++){
			if(List_Role.get(i) == Role.BODYGUARD & Alive[i] == 1){
				WOLF[i] = WOLF[i] + 50;
			}
		}

		//自信とのつながりのリセット
		for(int i = 0; i<15; i++){
			BELL[i][i] = 0;
		}
		//つながりの強い人の人狼度を反映
		for(int i = 0; i < 15; i++){
			int a = 0;//つながりの最大値
			for(int j = 0; j < 15; j++){
				if(a<BELL[i][j]+BELL[j][i]){
					a = BELL[i][j]+BELL[j][i];
				}
			}
			for(int j = 0; j < 15; j++){
				if(a == BELL[i][j]+BELL[j][i]){
					WOLF[i] = WOLF[i] + WOLF[j]/5;//相方の20%の人狼度を加算
				}
			}
		}

		//人狼度の最大値
		int WOLFMAX = 0;
		//投票対象の候補者リスト
		List<Agent> voteCandidates = new ArrayList<Agent>();
		voteCandidates.clear();
		//投票の優先順位
		if (COUNT_SEER + COUNT_MEDIUM > 5){//役職5人以上の場合役職を殺す
			for(int b = 0; b < 15; b++){
				if(List_Role.get(b) == Role.MEDIUM & Alive[b] ==1){
					voteCandidates.add(List_Agent.get(b));
					break;
				}
				if(List_Role.get(b) == Role.SEER & Alive[b] ==1){
					voteCandidates.add(List_Agent.get(b));
					break;
				}
			}
		//}else if(Alive_SEER == COUNT_SEER){//占いで人狼と占い師が一人も殺されていない場合占いで人狼と言われた人に投票
			//for(int b = 0; b < COUNT_DIVINED; b++){
				//if(List_DIVINED_Result.get(b) == Species.WEREWOLF & Alive[b] ==1){
					//voteCandidates.add(List_DIVINED_Target.get(b));
				//}
			//}
		}else
		//人狼度が高いやつに投票
		for(int i = 0; i < 15; i++){
			if(Alive[i]==0){
				continue;
			}
			if(WOLFMAX < WOLF[i]){
				WOLFMAX = WOLF[i];//人狼度の最大値の格納
			}
			for(int j = 0; j < 15; j++){
				if(WOLFMAX == WOLF[j] & Alive[j]==1){
					voteCandidates.add(List_Agent.get(j));
				}
			}
		}



		//if(blackAgent.size() > 0){
			//blackAgentがいればその中から選択
			//return blackAgent.get(0);
		//}else{
			//自分自身と白判定のプレイヤーは候補から外す
			return voteCandidates.get(0);
		//}
	}

}
